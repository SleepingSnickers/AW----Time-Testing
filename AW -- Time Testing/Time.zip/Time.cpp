#include "Time.h"

#include <iostream>

using namespace std;

Time::Time() {
	days = 0;
	hours = 0;
	minutes = 0;
	seconds = 0;
}

Time::Time(int days, int hours, int months, int seconds) {
	this->days = days;
	this->hours = hours;
	months = this->days * 30;
	this->seconds = seconds;
}

Time::Time(int hours, int minutes, int seconds) {
	this->hours = hours;
	this->minutes = minutes;
	this->seconds = seconds;
}

Time::Time(int hours, int minutes) {
	this->hours = hours;
	this->minutes = minutes;
}

int Time::getDays() const {
	return days;
}

void Time::setDays(int days) {
	this->days = days;
}

int Time::getHours() const {
	return hours;
}

void Time::setHours(int hours) {
	this->hours = hours;
}

int Time::getMinutes() const {
	return minutes;
}

void Time::setMinutes(int minutes) {
	int hours = minutes % 60;
	setHours(this->hours + hours);
	this->minutes = minutes - (hours * 60);
}

int Time::getSeconds() const {
	return seconds;
}

void Time::setSeconds(int seconds) {
	int minutes = seconds % 60;
	setMinutes(this->minutes + minutes);
	this->seconds = seconds - (minutes * 60);
}